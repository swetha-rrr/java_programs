/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

package com.mycompany.mavenproject7;
import java.sql.*;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Dell
 */
public class Attendee extends javax.swing.JFrame {

    /**
     * Creates new form Attendee
     */
    public Attendee() {
        initComponents();
        connect();
        Load();
    }
     
    Connection con;
    PreparedStatement pat;
    DefaultTableModel def;
     
    public void connect()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/newdetails","root","");

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Attendee.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Attendee.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    
    public void Load()
    {
        try {
            pat=con.prepareStatement("select * from regs");
            ResultSet rs=pat.executeQuery();
            ResultSetMetaData rss=rs.getMetaData();
            int c;
            c=rss.getColumnCount();
            def=(DefaultTableModel)jTable1.getModel();
            def.setRowCount(0);
            while(rs.next())
            {
                Vector v=new Vector();
                for(int i=0;i<c;i++)
                {
                    v.add(rs.getString("id"));
                     v.add(rs.getString("Name"));
                      v.add(rs.getString("Email"));
                       v.add(rs.getString("Contact_No"));
                            v.add(rs.getString("Country"));
                }
                def.addRow(v);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Attendee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Addbtn = new javax.swing.JButton();
        Delbtn = new javax.swing.JButton();
        Searchbtn = new javax.swing.JButton();
        Updatebtn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jTextField1 = new javax.swing.JTextField();
        txtName = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtContactNumber = new javax.swing.JTextField();
        txtCountry = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        Statisticsbtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 204, 204));

        Addbtn.setText("ADD");
        Addbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddbtnActionPerformed(evt);
            }
        });

        Delbtn.setText("Delete");
        Delbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DelbtnActionPerformed(evt);
            }
        });

        Searchbtn.setText("Search");
        Searchbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchbtnActionPerformed(evt);
            }
        });

        Updatebtn.setText("Update");
        Updatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdatebtnActionPerformed(evt);
            }
        });

        jLabel1.setText("Name");

        jLabel2.setText("Email");

        jLabel3.setText("Contact_No");

        jLabel4.setText("Country");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "id", "Name", "Email", "Contact_no", "Country"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jTextField1.setText("Students Registration");

        txtEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEmailActionPerformed(evt);
            }
        });

        txtContactNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtContactNumberActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Country", "Attendee_no"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        Statisticsbtn.setText("Statistics");
        Statisticsbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StatisticsbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(35, 35, 35)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(Addbtn)
                                        .addComponent(Searchbtn)))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(55, 55, 55)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                            .addGap(37, 37, 37)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtContactNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtCountry, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(81, 81, 81)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(305, 305, 305)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(154, 154, 154)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Delbtn)
                                    .addComponent(Updatebtn)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(85, 85, 85)
                                .addComponent(Statisticsbtn)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(514, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(22, 22, 22)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtContactNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtCountry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Addbtn)
                            .addComponent(Delbtn))
                        .addGap(35, 35, 35)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Updatebtn, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Searchbtn))
                        .addGap(36, 36, 36)
                        .addComponent(Statisticsbtn))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(49, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(98, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    //addbtn code starts here 
    
    private void AddbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddbtnActionPerformed
        
    try {
              String Name,Email,Contact_No,Country;
              
              Name=txtName.getText();
              Email=txtEmail.getText();
              Contact_No=txtContactNumber.getText();
              Country=txtCountry.getText();
              pat=con.prepareStatement("insert into regs(Name,Email,Contact_No,Country)values(?,?,?,?)");
              pat.setString(1,Name);
              pat.setString(2,Email);
              pat.setString(3,Contact_No);
              pat.setString(4,Country);
              pat.executeUpdate();
              JOptionPane.showMessageDialog(this,"Records Added");
              Load();
              txtName.setText("");
              txtEmail.setText("");
              txtContactNumber.setText("");
              txtCountry.setText("");
              txtName.requestFocus();

          } 

        catch (SQLException ex) {
              Logger.getLogger(Attendee.class.getName()).log(Level.SEVERE, null, ex);
          }
    }//GEN-LAST:event_AddbtnActionPerformed

    private void StatisticsbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StatisticsbtnActionPerformed
        
         try {
            
        // Creating CallableStatement to call the stored procedure
            CallableStatement callableStatement = con.prepareCall("{call GetAttendeeStatistics()}");

            boolean hasResults = callableStatement.execute();

            DefaultTableModel statisticsTableModel = (DefaultTableModel) jTable2.getModel();
            statisticsTableModel.setRowCount(0);

            while (hasResults) {
                ResultSet resultSet = callableStatement.getResultSet();

                // Update the jtable2 table
                while (resultSet.next()) {
                    String country = resultSet.getString("country");
                    int attendeeCount = resultSet.getInt("attendee_count");

                    Vector<Object> row = new Vector<>();
                    row.add(country);
                    row.add(attendeeCount);
                    statisticsTableModel.addRow(row);
                }

                hasResults = callableStatement.getMoreResults();
            }

            callableStatement.close();
        } catch (SQLException ex) {
            Logger.getLogger(Attendee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_StatisticsbtnActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        
        def=(DefaultTableModel)jTable1.getModel();
        int selected=jTable1.getSelectedRow();
        int id=Integer.parseInt(def.getValueAt(selected, 0).toString());
        txtName.setText(def.getValueAt(selected, 1).toString());
        txtEmail.setText(def.getValueAt(selected, 2).toString());
        txtContactNumber.setText(def.getValueAt(selected, 3).toString());
        txtCountry.setText(def.getValueAt(selected, 4).toString());
    }//GEN-LAST:event_jTable1MouseClicked

    private void DelbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DelbtnActionPerformed
        // TODO add your handling code here:
         def=(DefaultTableModel)jTable1.getModel();
        int selected=jTable1.getSelectedRow();
        int id=Integer.parseInt(def.getValueAt(selected, 0).toString());
        try {
            pat=con.prepareStatement("delete from regs where id=?");
            pat.setInt(1, id);
            pat.executeUpdate();
            JOptionPane.showMessageDialog(this,"Records Deleted");
            Load();
            txtName.setText("");
            txtEmail.setText("");
            txtContactNumber.setText("");
            txtCountry.setText("");
            txtName.requestFocus();
        } catch (SQLException ex) {
            Logger.getLogger(Attendee.class.getName()).log(Level.SEVERE, null, ex);
        
    }   

    }//GEN-LAST:event_DelbtnActionPerformed

    private void UpdatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdatebtnActionPerformed
        // TODO add your handling code here:
     def=(DefaultTableModel)jTable1.getModel();
        int selected=jTable1.getSelectedRow();
        int id=Integer.parseInt(def.getValueAt(selected, 0).toString());
        try {
            String Name,Email,Contact_No,Country;
            Name=txtName.getText();
            Email=txtEmail.getText();
            Contact_No=txtContactNumber.getText();
            Country=txtCountry.getText();
            pat=con.prepareStatement("update regs set Name=?,Email=?,Contact_No=?,Country=? where id=?");
            pat.setString(1,Name);
            pat.setString(2,Email);
            pat.setString(3,Contact_No);
            pat.setString(4,Country);
            pat.setInt(5, id);
            pat.executeUpdate();
            JOptionPane.showMessageDialog(this,"Records Updated");
            Load();
            txtName.setText("");
            txtEmail.setText("");
            txtContactNumber.setText("");
            txtCountry.setText("");
            txtName.requestFocus();
        } catch (SQLException ex) {
            Logger.getLogger(Attendee.class.getName()).log(Level.SEVERE, null, ex);
        
    }            
    }//GEN-LAST:event_UpdatebtnActionPerformed

    private void SearchbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchbtnActionPerformed
        // TODO add your handling code here:
        String searchCriteria = JOptionPane.showInputDialog(this, "Enter search criteria:");

        if (searchCriteria != null && !searchCriteria.isEmpty()) {
            try {
                pat = con.prepareStatement("SELECT * FROM regs WHERE id = ? or Name = ? or Country = ?");
                pat.setString(1, searchCriteria);
                pat.setString(2, searchCriteria);
                pat.setString(3, searchCriteria);


                try (ResultSet rs = pat.executeQuery()) {
                    def = (DefaultTableModel) jTable1.getModel();
                    def.setRowCount(0);

                    if (rs.next()) {
                        Vector v = new Vector();
                        v.add(rs.getString("id"));
                        v.add(rs.getString("Name"));
                        v.add(rs.getString("Email"));
                        v.add(rs.getString("Contact_No"));
                        v.add(rs.getString("Country"));
                        def.addRow(v);

                        // Display the first result in the text fields
                        txtName.setText(rs.getString("Name"));
                        txtEmail.setText(rs.getString("Email"));
                        txtContactNumber.setText(rs.getString("Contact_No"));
                        txtCountry.setText(rs.getString("Country"));

                    } else {
                        JOptionPane.showMessageDialog(this, "No matching records found.");
                    }
                }
            } catch (SQLException ex) {
                Logger.getLogger(Attendee.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please enter a valid search criteria.");
        }
     
    }//GEN-LAST:event_SearchbtnActionPerformed

    private void txtEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmailActionPerformed

    private void txtContactNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtContactNumberActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtContactNumberActionPerformed

    /**
     * @param args the command line arguments
     */

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AttendeeInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AttendeeInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AttendeeInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AttendeeInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Attendee().setVisible(true);
            }
        });
    }



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Addbtn;
    private javax.swing.JButton Delbtn;
    private javax.swing.JButton Searchbtn;
    private javax.swing.JButton Statisticsbtn;
    private javax.swing.JButton Updatebtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField txtContactNumber;
    private javax.swing.JTextField txtCountry;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtName;
    // End of variables declaration//GEN-END:variables


        
}