/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject7;

/**
 *
 * @author Dell
 */
public class Mavenproject7 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
