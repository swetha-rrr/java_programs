/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



/**
 *
 * @author Dell
 */
public class Library {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
